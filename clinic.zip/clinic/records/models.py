from django.db import models

# Create your models here.
from django.db import models

class Patient(models.Model):
    name = models.CharField(max_length=255)
    age = models.PositiveIntegerField()
    contact = models.CharField(max_length=20)
    diagnosis = models.TextField()
    admission_date = models.DateField()


